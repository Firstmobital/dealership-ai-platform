-- Ensure vector extension is available
CREATE EXTENSION IF NOT EXISTS vector;

-- Fix missing column for embeddings
ALTER TABLE knowledge_chunks
ADD COLUMN IF NOT EXISTS embedding vector(1536);

-- Optional: clean old bad columns if they exist
ALTER TABLE knowledge_chunks
DROP COLUMN IF EXISTS embedding_vector,
DROP COLUMN IF EXISTS embeddings;

-- Ensure foreign key is correct
ALTER TABLE knowledge_chunks
ADD CONSTRAINT fk_chunks_article
FOREIGN KEY (article_id)
REFERENCES knowledge_articles(id)
ON DELETE CASCADE;

-- Ensure service role RLS policy
DROP POLICY IF EXISTS "service_role_only_knowledge_chunks" ON knowledge_chunks;
CREATE POLICY "service_role_only_knowledge_chunks"
ON knowledge_chunks
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);
